#install.packages("corrr")
library('corrr')

#install.packages("ggcorrplot")
library(ggcorrplot)


BreastCancer <- read.csv("cancer.csv")# Read & assign the file "cancer.csv" to a variable "BreastCancer" 
str(BreastCancer) # uses the Str() function to display structure of the BreastCancer object.

colSums(is.na(BreastCancer))

numerical_data <- BreastCancer[,2:10]

head(numerical_data)

corr_matrix <- cor(data_normalized)
ggcorrplot(corr_matrix)


data.pca <- princomp(corr_matrix)
summary(data.pca)

data.pca$loadings[, 1:2]

fviz_eig(data.pca, addlabels = TRUE)

eigenvalues <- data.pca$sdev^2

print(eigenvalues)

proportion_variance <- eigenvalues / sum(eigenvalues)
print(proportion_variance)

cumulative_proportion_variance <- cumsum(proportion_variance)

print(cumulative_proportion_variance)



