# Install packages
# install.packages("corrr")
# install.packages("FactoMineR")
# install.packages("factoextra")
# install.packages("MASS")
# install.packages("GOplot")

# Load Libraries
library(MASS)
library(factoextra)
library(ggplot2)


# import cancer data
cancer
dim(cancer)

# structure my data
str(cancer)
summary(cancer)

# Delete cases with with missingness
cancer_nomiss <- na.omit(cancer)

# Exclude Categorical Data
breast_cancer <- cancer_nomiss[, -c(1,11)]

# Convert the entire Dataset to Numeric data/values
#breast_cancer <- as.numeric(breast_cancer)

 

cancer

# Run PCA 
breast_cancer_pca <- prcomp(breast_cancer, scale = TRUE)







